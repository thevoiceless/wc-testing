char *s = N_("\"Wrap Around\" the Games List & Options menu.");
char *s = N_("# Games");
char *s = N_("<b>Emulator</b>");
char *s = N_("<b>Test:</b>");
char *s = N_("<b>or</b>");
char *s = N_("Add Emulator");
char *s = N_("Add New Emulator");
char *s = N_("Add new List");
char *s = N_("Also see the \"Display Mouse Cursor\" option (Wah!Cade Tab)");
char *s = N_("Also see the \"Use Mouse\" option (Keys Tab)");
char *s = N_("Alternative #1");
char *s = N_("Alternative #2");
char *s = N_("Application");
char *s = N_("Application #1");
char *s = N_("Application #2");
char *s = N_("Application #3");
char *s = N_("Application Parameters");
char *s = N_("Artwork");
char *s = N_("Artwork # that Movies will be displayed in");
char *s = N_("Artwork #1");
char *s = N_("Artwork #10");
char *s = N_("Artwork #2");
char *s = N_("Artwork #3");
char *s = N_("Artwork #4");
char *s = N_("Artwork #5");
char *s = N_("Artwork #6");
char *s = N_("Artwork #7");
char *s = N_("Artwork #8");
char *s = N_("Artwork #9");
char *s = N_("Auto Launch Apps");
char *s = N_("Cancel");
char *s = N_("Category / Version File");
char *s = N_("Check this for list to be included in Next / Previous List selection");
char *s = N_("Command Line");
char *s = N_("Command Line Format, where:\n"
             "  [name] is replaced by the selected Rom name\n"
             "  [rompath] is replaced by the Rom Directory\n"
             "  [romext] is replaced by the Rom Extension\n"
             "  [autorotate] will rotate the screen (Mame only)\n"
             "  {minimize} will minimize wah!cade after launching the application\n"
             "  {music} allows music playback to continue after launching the application\n"
             "\n"
             ".e.g.  [name].[romext] -p [rompath] would be:\n"
             "  asteroids.zip -p /home/user/some/path\n"
             "");
char *s = N_("Command Line Format, where:\n"
             "  [name] is replaced by the selected Rom name\n"
             "  [rompath] is replaced by the Rom Directory\n"
             "  [romext] is replaced by the Rom Extension\n"
             "  {minimize} will minimize wah!cade after launching the application\n"
             "\n"
             ".e.g.  [name].[romext] -p [rompath] would be:\n"
             "  asteroids.zip -p /home/user/some/path\n"
             "");
char *s = N_("Control Panel Viewer");
char *s = N_("Controls File");
char *s = N_("Correctly Scale Images");
char *s = N_("Cycle List");
char *s = N_("Data File");
char *s = N_("Delay (secs)");
char *s = N_("Delete this List");
char *s = N_("Directory for Movies that will be used in the layout.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#1 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#10 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#2 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#3 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#5 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#6 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#7 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#8 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork#9 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Directory for artwork that will be used in the layouts Artwork4 image.\n"
             "(also see Wah!Cade Layout Editor)");
char *s = N_("Display Mouse Cursor");
char *s = N_("Display Scroll Arrows in Lists");
char *s = N_("Edit Game List");
char *s = N_("Edit List");
char *s = N_("Emulators");
char *s = N_("Exit Movie");
char *s = N_("External Applications");
char *s = N_("External Screen Saver");
char *s = N_("Extra");
char *s = N_("FullScreen");
char *s = N_("Generate XML File");
char *s = N_("History Viewer");
char *s = N_("Intro Movie");
char *s = N_("Joystick");
char *s = N_("Keyboard");
char *s = N_("Keys");
char *s = N_("Layout Directory");
char *s = N_("Layout File");
char *s = N_("Layout directory name (in ~/wahcade/layouts)");
char *s = N_("List #");
char *s = N_("List Editor");
char *s = N_("List Generation");
char *s = N_("List Generation Method");
char *s = N_("List Specific Application Parameters");
char *s = N_("List Title");
char *s = N_("List Type");
char *s = N_("Lists");
char *s = N_("Location of music");
char *s = N_("MAME Info (.xml or .dat file)");
char *s = N_("Method used to create game lists:\n"
             "1) Rom Directory: Scan the directory for games matching given Rom Extension.\n"
             "2) XML File: Scan the .xml file matching on games in given Rom Directory.\n"
             "3) DAT File: Scan the .dat file matching on games in given Rom Directory.\n"
             "\n"
             "* XML & DAT File methods are for Mame only.");
char *s = N_("Misc");
char *s = N_("Mouse");
char *s = N_("Movie Artwork #");
char *s = N_("Movie Directory");
char *s = N_("Movies");
char *s = N_("Music");
char *s = N_("Music / Movie Mix");
char *s = N_("NMS File");
char *s = N_("Number of seconds before Screen Saver starts");
char *s = N_("Number of seconds to display Screen Saver image / movie");
char *s = N_("Play Music From");
char *s = N_("Please Wait.  Creating Initial Filter...      ");
char *s = N_("Remove Current Emulator");
char *s = N_("Reset Filters");
char *s = N_("Reset Setup");
char *s = N_("Rom Directory");
char *s = N_("Rom Directory\n"
             "XML File (Mame Only)\n"
             "DAT File (Mame Only)\n"
             "");
char *s = N_("Rom Extension");
char *s = N_("Screen Saver");
char *s = N_("Screen Saver Delay (secs)");
char *s = N_("Screen Saver Slide Duration (secs)");
char *s = N_("Screen Saver Type");
char *s = N_("Select Joystick Control");
char *s = N_("Select Key");
char *s = N_("Select Mouse Control");
char *s = N_("Set Category / Version File");
char *s = N_("Set Exit Movie");
char *s = N_("Set Filter");
char *s = N_("Set Intro Movie");
char *s = N_("Set XML / Data File");
char *s = N_("Setup Filters...");
char *s = N_("Show scroll up / down arrows in Games, Options and History Viewer lists.");
char *s = N_("Shuffle Playlist");
char *s = N_("Start Wah!Cade in fullscreen mode");
char *s = N_("The Control Panel Viewer layout file location (.lay)");
char *s = N_("The background image (if any) for the history viewer window.");
char *s = N_("The catver.ini file location");
char *s = N_("The controls.ini file location");
char *s = N_("The history.dat file");
char *s = N_("The location of the emulator executable");
char *s = N_("The order applications are launched prior to the emulator, eg 1,2,3 or 3,2,1 or 1,2 or 1 etc.");
char *s = N_("This gets displayed in the Layout");
char *s = N_("Title");
char *s = N_("Use Joystick");
char *s = N_("Use Keyboard");
/* xgettext:no-c-format */
char *s = N_("Volume (%)");
char *s = N_("Wah!Cade");
char *s = N_("Wah!Cade Setup");
char *s = N_("Wrap Lists");
char *s = N_("XML / Data File");
char *s = N_("[Joystick Action]");
char *s = N_("_About");
char *s = N_("_File");
char *s = N_("_Help");
char *s = N_("_Remove Game");
char *s = N_("_Reset Filter");
char *s = N_("n Games");
char *s = N_("wahcade-cp-viewer\n"
             "wahcade-history-viewer");
