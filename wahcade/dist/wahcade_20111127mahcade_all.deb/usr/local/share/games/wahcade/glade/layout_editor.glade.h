char *s = N_("0\n"
             "90\n"
             "180\n"
             "270");
char *s = N_("1200\n"
             "1024\n"
             "768\n"
             "600\n"
             "480");
char *s = N_("1600\n"
             "1280\n"
             "1024\n"
             "800\n"
             "640");
char *s = N_("Background Colour");
char *s = N_("Background Image");
char *s = N_("Bar Colour");
char *s = N_("CP Viewer");
char *s = N_("Centre");
char *s = N_("Control Panel Viewer Window");
char *s = N_("Full Screen");
char *s = N_("History Window");
char *s = N_("Item Properties");
char *s = N_("Item _Properties");
char *s = N_("Layout");
char *s = N_("Layout Properties");
char *s = N_("Leave unchecked for Wah!Cade to auto-detect background images.");
char *s = N_("Left");
char *s = N_("M_essage Window");
char *s = N_("Main Window");
char *s = N_("Message Window");
char *s = N_("Name");
char *s = N_("Open History Layout");
char *s = N_("Open _CP Viewer Layout");
char *s = N_("Options Window");
char *s = N_("Position (X,Y)");
char *s = N_("Properties");
char *s = N_("Properties On Top");
char *s = N_("Right");
char *s = N_("Rotation");
char *s = N_("S_creen Properties");
char *s = N_("Save C_P Viewer Layout As");
char *s = N_("Save History Layout As");
char *s = N_("Save Layout(s)");
char *s = N_("Save Wah!Cade Layout _As");
char *s = N_("Screen Properties");
char *s = N_("Screen Saver Window");
char *s = N_("Select _All (Visible)");
char *s = N_("Selected Colour");
char *s = N_("Set Background Image");
char *s = N_("Size (Width x Height)");
char *s = N_("Size (Width, Height)");
char *s = N_("Text Alignment");
char *s = N_("Text Colour");
char *s = N_("Text Font");
char *s = N_("Transparent");
char *s = N_("Visible");
char *s = N_("Wah!Cade Layout Editor");
char *s = N_("_About");
char *s = N_("_Edit");
char *s = N_("_File");
char *s = N_("_Help");
char *s = N_("_Main Window");
char *s = N_("_Open Wah!Cade Layout");
char *s = N_("_Options Window");
char *s = N_("_Screen Saver Window");
char *s = N_("_Select All");
char *s = N_("_View");
